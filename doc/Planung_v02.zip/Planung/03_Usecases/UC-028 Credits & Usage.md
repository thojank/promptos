---
id: UC-028
status: draft
epic: E-004
priority: P0
kpi: cost_per_user, blocked_actions_rate
---

# UC-028 – Credits & Usage

## Nutzerwert
- Kostenkontrolle, klare Limits, Skalierung ohne Überraschungen.

## Main Flow
1. Aktion starten (z.B. Import)
2. System prüft Plan/Quota
3. System zieht Credits atomar ab
4. UI zeigt Balance/Remaining

## Output
- Updated balance + ledger entry
