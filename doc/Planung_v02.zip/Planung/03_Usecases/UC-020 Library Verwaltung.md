---
id: UC-020
status: draft
epic: E-002
priority: P0
kpi: time_to_find_asset, assets_with_tags_ratio
---

# UC-020 – Library Verwaltung (Styles/Environments)

## Nutzerwert
- Assets organisieren und schnell wiederfinden.

## Main Flow
- CRUD für Assets
- Tags/Filter/Search/Sort
- Owner-only Zugriff (RLS)

## Output
- Persistente Library Items
