---
id: UC-034
status: draft
epic: E-004
priority: P0
kpi: api_key_usage, unauthorized_rate
---

# UC-034 – API Keys (Basic)

## Nutzerwert
- Automatisierung/Integrationen ohne UI.

## Main Flow
1. Key erstellen (show once)
2. Key nutzen (auth middleware)
3. Key revoken

## Output
- API Key + scope metadata
