# ADR-0002 Credit Model

Status: Draft

Kontext, Entscheidung, Konsequenzen.
