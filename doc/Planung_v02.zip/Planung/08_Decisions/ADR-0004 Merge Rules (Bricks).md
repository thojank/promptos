---
id: ADR-0004
date: 2026-02-04
status: proposed
---

# ADR-0004 – Merge Rules (Bricks)

## Entscheidung (Proposal)
Bricks mergen nur ihren Subtree (Style oder Environment). Konflikte werden explizit gemacht und vom Nutzer gelöst.

## Konsequenzen
- Keine stillen Overwrites
- Merge Preview + Undo nötig
