---
id: ADR-0005
date: 2026-02-04
status: proposed
---

# ADR-0005 – Credits & Limits Modell

## Entscheidung (Proposal)
Plans/Limits vor Credits prüfen. Credits werden atomar abgezogen und im Ledger protokolliert.

## Konsequenzen
- Kosten kontrollierbar
- Saubere Audit-Spur für Abrechnung
