# Acceptance Tests (Gherkin)

Gherkin-Szenarien und Akzeptanztests.
