# Schnipsel

Kurze Notizen, Links, Ideen.
