# Adapter – Flux

Integration, Mapping, Beispiele.
