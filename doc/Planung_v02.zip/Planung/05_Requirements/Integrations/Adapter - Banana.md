# Adapter – Banana

Integration, Mapping, Beispiele.
