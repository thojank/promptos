# NFR-001 Rate limiting

Nicht-funktionale Anforderungen, Limits, Messung.
