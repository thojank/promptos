# Tables – Supabase

Tabellenübersicht, Felder, Indizes.
