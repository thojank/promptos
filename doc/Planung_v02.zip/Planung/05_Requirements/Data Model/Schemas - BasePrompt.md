# Schemas – BasePrompt

Schema-Definitionen und Versionierung.
