# Entities

Domänenobjekte, Attribute, Beziehungen.
