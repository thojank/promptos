# Customer Journey

Phasen, Touchpoints, Schmerzpunkte.
